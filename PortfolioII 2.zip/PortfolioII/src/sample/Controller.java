package sample;

import Connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import java.sql.SQLException;

public class Controller {

    public ConnectionClass connectionClass = new ConnectionClass();
    public TextArea textArea;

    public void search(ActionEvent actionEvent)
    throws Exception{
        String Output = ConnectionClass.viewTable(combobox2.getValue().toString(),combobox1.getValue().toString(),combobox3.getValue().toString());
        textArea.setText(Output);
    }

    public Controller() throws SQLException {
    }

    @FXML
    ComboBox combobox1;
    @FXML
    ComboBox combobox2;
    @FXML
    ComboBox combobox3;


    @FXML
    public void initialize() throws SQLException {

        String[] stations = ConnectionClass.getStations();
        combobox1.getItems().addAll(stations);
        combobox2.getItems().addAll(stations);

        for(String s: TimeModel.getIns().getTime()) {
            combobox3.getItems().add(s);
        }
    }
}



class TimeModel{
    private TimeModel(){}
    static TimeModel inst;
    static TimeModel getIns(){if(inst==null)inst=new TimeModel(); return inst;}
    String[] getTime(){String[] s={"01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00"}; return s;}
    String findRoute(String stat3,String stat4, String time){
        return "route from "+stat3+"\n to "+stat4+" at "+time;
    }
}
