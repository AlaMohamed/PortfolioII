package Connectivity;

import java.sql.*;
import java.util.ArrayList;

public class ConnectionClass {
public static Connection conn = null;

    public ConnectionClass () throws SQLException {

        String url = "jdbc:sqlite:/Users/alamohamed/Downloads/Train2/src/TrainSchedule.db";
        conn = DriverManager.getConnection(url);
    }

        public static String[] getStations(){
            String query = "Select station_name from STATION";
            ArrayList <String> S = new ArrayList<String>();

            try {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(query);
                while( rs.next()) {
                    String startCity = rs.getString("station_name");
                    S.add(startCity);
                }
            }
            catch (SQLException e) {
                System.err.println(e);
            }
            return S.toArray(new String[0]);
        }

       public static String viewTable(String To, String From, String Time) {
        String query = "SELECT start.departure_time, stationStart.station_name, end.departure_time, stationEnd.station_name, start.destination_id, start.departure_id" +
                " FROM ROUTE as start" +
                " INNER JOIN DESTINATION ON start.destination_id = destination.destination_id" +
                " AND destination.departure_id = start.departure_id" +
                " INNER JOIN ROUTE as end ON start.destination_id = end.destination_id" +
                " AND start.departure_id = end.departure_id" +
                " INNER JOIN STATION as stationEnd ON end.station_id = stationEnd.station_id" +
                " INNER JOIN STATION as stationStart ON start.station_id = stationStart.station_id" +
                " WHERE stationStart.station_name = ? " +
                " AND stationEnd.station_name =  ?" +
                " AND start.departure_time <=  ?" +
                " AND end.departure_time > start.departure_time";
           String Output = "";

        try {
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1,  From );
        stmt.setString(2, To);
        stmt.setString(3, Time);
            ResultSet rs = stmt.executeQuery();
            while( rs.next()) {
                String startStation = rs.getString(1);
                String endStation = rs.getString(2);
                String departureTime = rs.getString(3);
                System.out.println(startStation +", " + departureTime  + ", " +endStation);
                Output = Output + "Train to: " +endStation + "\n" + "from: " +startStation + "\n"+ " leaves at: " + departureTime +"\n" +"\n";
            }
        }
        catch (SQLException e) {
            System.err.println(e);
            e.printStackTrace();

        }
        return Output;
    }
}
